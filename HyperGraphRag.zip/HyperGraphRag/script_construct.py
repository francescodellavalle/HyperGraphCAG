import os
import json
from hypergraphrag import HyperGraphRAG
#os.environ["OPENAI_API_KEY"] = "your_openai_api_key"

#rag = HyperGraphRAG(working_dir=f"expr/example")
rag = HyperGraphRAG(
    working_dir="expr/example",
    embedding_func=lambda: hf_embedding,  # usa Hugging Face
    llm_model_func=hf_model_complete,
    llm_model_name="tiiuae/falcon-7b-instruct",  # oppure altro modello HF
)

with open(f"example_contexts.json", mode="r") as f:
    unique_contexts = json.load(f)
    
rag.insert(unique_contexts)