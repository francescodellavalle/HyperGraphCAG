from pathlib import Path
from hypergraphrag.base import BaseGraphStorage, BaseVectorStorage, BaseKVStorage
from hypergraphrag.hypercag import HyperGraphCAGEngine
from hypergraphrag.utils import compute_mdhash_id
from tqdm import tqdm


class HyperGraphCAGRAG:
    def __init__(
        self,
        graph_store: BaseGraphStorage,
        entity_vdb: BaseVectorStorage,
        hyperedge_vdb: BaseVectorStorage,
        text_store: BaseKVStorage,
        hashing_kv: BaseKVStorage,
        model_name: str,
        kv_cache_dir: str = "./cag_cache",
        hf_token: str = None
    ):
        self.graph = graph_store
        self.entity_vdb = entity_vdb
        self.hyperedge_vdb = hyperedge_vdb
        self.text_store = text_store
        self.hashing_kv = hashing_kv
        self.llm_model_func = None
        self.embedding_func = entity_vdb.embedding_func  # ✅ necessario per query_with_cache
        self.cag_engine = HyperGraphCAGEngine(
            model_name=model_name,
            kv_cache_dir=kv_cache_dir,
            hf_token=hf_token
        )

    async def ainsert_kvcache(self):
        all_nodes = list(self.graph._graph.nodes)
        all_hyperedges = [
            n for n in all_nodes
            if self.graph._graph.nodes[n].get("role") == "hyperedge"
        ]
        for he in all_hyperedges:
            node_data = await self.graph.get_node(he)
            source_id = node_data.get("source_id")
            if not source_id:
                continue
            chunk = await self.text_store.get_by_id(source_id)
            if not chunk:
                continue
            prompt_text = f"{he}\n\n{chunk['content']}"
            cache_id = compute_mdhash_id(he, prefix="cag-")
            self.cag_engine.preprocess_knowledge_to_kvcache(cache_id, prompt_text)

    async def aquery(self, query: str, *args, **kwargs):
        knowledge_id = compute_mdhash_id(query, prefix="cag-")
        return self.cag_engine.generate_from_cache(query, knowledge_id)

    async def cache_all_entities(self):
        print("🚀 Avvio generazione cache per tutte le entità...")
        for node in self.graph._graph.nodes:
            node_data = self.graph._graph.nodes[node]
            if node_data.get("role") != "entity":
                continue

            source_id = node_data.get("source_id")
            if not source_id:
                print(f"⚠️ Nodo entità '{node}' senza source_id.")
                continue

            chunk = await self.text_store.get_by_id(source_id)
            if not chunk:
                print(f"⚠️ Chunk mancante per '{source_id}'.")
                continue

            prompt_text = f"{node}\n\n{chunk['content']}"
            cache_id = compute_mdhash_id(node, prefix="cag-entity-")
            self.cag_engine.preprocess_knowledge_to_kvcache(cache_id, prompt_text)
            print(f"✅ Cache salvata per entità: {node} → {cache_id}.pt")

    async def cache_all_hyperedges(self):
      #print("🚀 Avvio generazione cache per tutti gli hyperedge...")

      hyperedge_nodes = [
        node for node in self.graph._graph.nodes
        if self.graph._graph.nodes[node].get("role") == "hyperedge"
      ]

      for node in tqdm(hyperedge_nodes, desc="📦 Caching hyperedges", unit="hyperedge"):
        node_data = self.graph._graph.nodes[node]

        source_id = node_data.get("source_id")
        if not source_id:
            print(f"⚠️ Nodo '{node}' senza source_id.")
            continue

        chunk = await self.text_store.get_by_id(source_id)
        if not chunk or "content" not in chunk:
            print(f"⚠️ Chunk mancante o incompleto per '{source_id}'.")
            continue

        prompt_text = f"{node}\n\n{chunk['content']}"
        cache_id = compute_mdhash_id(node, prefix="cag-")

        self.cag_engine.preprocess_knowledge_to_kvcache(cache_id, prompt_text)
        # print(f"✅ Cache salvata per: {node} → {cache_id}.pt")  # debug disabilitato


