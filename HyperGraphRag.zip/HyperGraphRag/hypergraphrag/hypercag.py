import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, DynamicCache
from pathlib import Path


class HyperGraphCAGEngine:
    def __init__(self, model_name, kv_cache_dir, use_quant_4bit=True, hf_token=None):
        self.model_name = model_name
        self.kv_cache_dir = Path(kv_cache_dir)
        self.kv_cache_dir.mkdir(parents=True, exist_ok=True)
        self.use_quant_4bit = use_quant_4bit
        self.hf_token = hf_token
        self._load_model()

    def _load_model(self):
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
        ) if self.use_quant_4bit else None

        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name, token=self.hf_token)
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            device_map="auto",
            token=self.hf_token,
            quantization_config=quant_config,
        )
        torch.serialization.add_safe_globals([DynamicCache])
        torch.serialization.add_safe_globals([set])
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def preprocess_knowledge_to_kvcache(self, knowledge_id: str, knowledge_prompt: str):
        input_ids = self.tokenizer.encode(knowledge_prompt, return_tensors="pt").to(self.device)
        past_key_values = DynamicCache()
        with torch.no_grad():
            self.model(
                input_ids=input_ids,
                past_key_values=past_key_values,
                use_cache=True,
            )
        cache_path = self.kv_cache_dir / f"{knowledge_id}.pt"
        kv_cache = self.get_kv_cache_from_prompt(knowledge_prompt)  # ✅ aggiunto!
        torch.save({
          "prompt": knowledge_prompt,
          "kv_cache": kv_cache
        }, cache_path)
        return cache_path

    def load_kvcache(self, knowledge_id: str):
        cache_path = self.kv_cache_dir / f"{knowledge_id}.pt"
        if not cache_path.exists():
            raise FileNotFoundError(f"KV-cache not found for: {knowledge_id}")
        return torch.load(cache_path)
    
    def generate_from_multiple_cache(self, query: str, cache_ids: list[str], query_cache_id: str):
        prompt = f"{query}"
        # (In this simplified version, multiple caches aren't used in generation, only prep)
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        output = self.model.generate(**inputs, max_new_tokens=256)
        return self.tokenizer.decode(output[0], skip_special_tokens=True)

    def generate_from_cache(self, query: str, knowledge_id: str, max_new_tokens=256):
        past_key_values = self.load_kvcache(knowledge_id)
        input_ids = self.tokenizer.encode(query, return_tensors="pt").to(self.device)
        output_ids = input_ids.clone()
        next_token = input_ids

        with torch.no_grad():
            for _ in range(max_new_tokens):
                outputs = self.model(
                    input_ids=next_token,
                    past_key_values=past_key_values,
                    use_cache=True,
                )
                next_token_logits = outputs.logits[:, -1, :]
                next_token = next_token_logits.argmax(dim=-1).unsqueeze(-1)
                next_token = next_token.to(self.device)
                past_key_values = outputs.past_key_values
                output_ids = torch.cat([output_ids, next_token], dim=1)
                if next_token.item() in self.tokenizer.all_special_ids:
                    break

        decoded = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return decoded.strip()
    
    def get_kv_cache_from_prompt(self, prompt: str):
      inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
      with torch.no_grad():
        outputs = self.model(**inputs, use_cache=True)
      return outputs.past_key_values

    def generate_from_fused_cache(self, query: str, fused_kv, max_new_tokens=150):
      from transformers.cache_utils import DynamicCache

      # Converti fused_kv in DynamicCache
      dynamic_cache = DynamicCache.from_legacy_cache(fused_kv)

      # Prepara input della query
      input_ids = self.tokenizer.encode(query, return_tensors="pt").to(self.model.device)
      output_ids = input_ids.clone()
      next_token = input_ids

      with torch.no_grad():
        for _ in range(max_new_tokens):
            outputs = self.model(
                input_ids=next_token,
                past_key_values=dynamic_cache,
                use_cache=True,
            )
            next_token_logits = outputs.logits[:, -1, :]
            next_token = next_token_logits.argmax(dim=-1).unsqueeze(-1).to(self.model.device)
            dynamic_cache = outputs.past_key_values
            output_ids = torch.cat([output_ids, next_token], dim=1)

            if next_token.item() in self.tokenizer.all_special_ids:
                break

      decoded = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
      return decoded.strip()
